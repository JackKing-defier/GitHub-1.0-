exports.app_key = "36071f02460d9612397bf5ee1f16fadf";
exports.getLocation = false;
exports.getUserinfo = false;
exports.appid = "";
exports.appsecret = "";
exports.defaultPath = "pages/store/store-home/index";